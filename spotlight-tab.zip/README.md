# spotlight-tab

spotlight like search for chrome tabs

https://chrome.google.com/webstore/detail/spotlight-tab/jnclmdcimnnjilkekhappojnlpigcdnm

## Usage

- `ctrl(cmd) + \` to bring up the search bar
- `ctrl(cmd) + shift + \` to quick switch between two tabs
