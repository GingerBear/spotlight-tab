# spotlight-tab

spotlight like search for chrome tabs
